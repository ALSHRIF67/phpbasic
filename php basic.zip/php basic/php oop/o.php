<?php

class Student
{
 public $name = 'Chris';
}
class School
{
 public $name = 'University of Edinburgh';
}
function enroll(Student $student, School $school)
{
 echo $student->name . ' is being enrolled at ' . $school->name;
}
$student = new Student();
$school = new School();
enroll($student, $school);









?>