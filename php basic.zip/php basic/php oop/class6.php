<?php
class  car {
    protected  static $brand="unknow";
    public static function brand(){
//That's because self refers to the Car class whenever method brand() is called.

//return self ::$brand. "</br>";
//To refer to the correct class, you need to use static instead:

return static ::$brand. "</br>";


    }
}


class seondcar extends car {
    protected static $brand ="seond car";
}


class thcar extends car {
    protected static $brand ="there car";


}




echo (new car)->brand();
echo (new seondcar)->brand();
echo (new thcar)->brand();
//output
//unknown
//unknown
//unknown
// seoand output 
///unknow</br>seond car</br>there car</br>





?>