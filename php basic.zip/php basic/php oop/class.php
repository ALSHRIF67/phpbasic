<?php
 class person {
public $name ;
public $email ;
public $address;
public $age ;

public function __construct($name, $email,$address,$age)
{
    $this->name =$name;
    $this->email =$email;
    $this->age=$age;
    $this->address=$address;


}
public function login(){
     echo " user login  ";
}





 }




$userone= new person("hellos","mro04860@gmail.com",'gadarif',23);
echo $userone->name;
 echo $userone->email;
echo $userone->age;
echo $userone->address;

echo $userone->login();

























?>