<?php




 class peroson
 {

function setName($name,$age,$A){
    $this->name=$name;
    $this->age=$age;
    $this->A=$A;


 
}
function getName(){
    echo " <br/>".$this->name;
    echo "<br/>".$this->age;
    echo "<br/>".$this->A;


}
}
 class omer extends peroson{
    function setName($address,$number,$code){
        $this->address=$address;
        $this->number=$number;
        $this->code=$code;
    
    
     
    }
    function getName(){
        echo " <br/>".$this->address;
        echo "<br/>".$this->number;
        echo "<br/>".$this->code;
    
    
    }

 }
$object = new peroson;
$object->setName("how ",12,"do you know me ");
$object->getName();

$B = new omer;
$B->setName("gadarif ",1290,789);
$B->getName();






?>