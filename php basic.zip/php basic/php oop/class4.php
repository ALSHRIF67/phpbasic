<?php
///A class with const values and how to access it 
  class math {
     const PI=3.18;
     const R = 5;

    }
  $area= math:: PI *math::R*math::R;
  echo $area;







 

?>