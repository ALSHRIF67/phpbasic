<?php
final class BaseClass {
    public function test() {
    echo "BaseClass::test() called\n";
    }
    // Here it doesn't matter if you specify the function as final or not
    final public function moreTesting() {
    echo "BaseClass::moreTesting() called\n";
    }
   }
   


?>