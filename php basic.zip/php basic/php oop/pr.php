<?php
$how=new you ;
$how->name ="omer";
$how->age= "18";
$how->emai="mr4853@gmai.com";
$how->dis();
class per{
 function hello(){
    echo" how are you ";
 }
}

class you extends per{
    public $age, $email;
    function dis(){
    echo"name  :".$this->name."<br/>";
    echo "age: " . $this->age . "<br>";
    echo "email: " . $this->email . "<br>";
}}









?>