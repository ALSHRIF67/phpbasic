<?php
//create classs  myclass

//verable vule test 

/// proteded function mymthod
class myclass{
protected $myu =  'test';

    protected function myMethod(){
     return $this->myu;
    }


}

///inhert subclass from my class
 class mysubclass extends myclass{
 public function run(){
    echo $this->myMethod();
 }
}
$object = new  mysubclass();
$object->run();


///crate object from subclass 











?>