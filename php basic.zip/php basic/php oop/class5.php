
<?php







class MyClass {
    // Property
    public $myProperty = 'test';
    // Method
    public function myMethod() {
    return $this->myProperty;
    }
   }
   $obj = new MyClass();
   echo $obj->myMethod();
   // Out: test
   echo $obj->myProperty;








?>