<?php
class pie{
    public $fruite ;
    public function  __construct($fruite){
        $this->fruite=$fruite;
    }
    

}

$pie=new pie("bananna");



?>