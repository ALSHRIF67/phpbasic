<?php
class user{
 public $email;
 public $name;
 public function  __construct()
 {
$this->email="mr048530@gmail.com";
 }
public function login (){
    echo" user login in ";
}
}
  $userone =  new user();
  $userone->login();
 
  echo $userone->email;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 
 
</body>
</html>





