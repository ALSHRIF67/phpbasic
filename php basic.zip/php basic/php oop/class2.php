<?php

class labor{
     const labor_units= 12.8;
     const labor_cost= 1.8;

public function getlaborcost($number_unite){
    return self::labor_units*self::labor_cost*$number_unite;

}

}












?>