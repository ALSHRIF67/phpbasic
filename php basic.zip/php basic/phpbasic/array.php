<?php
$arr=array('A','B','C','D');
echo "<br/>".$arr[0];
echo "<br>".$arr[1];
echo" <br/>".$arr[2];
echo" <br/>".$arr[3];








?>