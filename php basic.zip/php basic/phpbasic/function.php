 <?php
 //function echo massage
 function loginuser(){
    echo" user login succssfull";
 }
//call function 

loginuser();


//function with paramaters
function sum($num , $numt){
    echo " <br/> sum =" .($num+$numt);
}
sum(10,20);
//function with return value 
function mynum($num , $numt){
    return$num+$numt;
}
 echo "<br/>".mynum(20,20);

?>