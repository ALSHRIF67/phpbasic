<?php
$test=18;
if($test<18){
    echo" you are younage ";
}else{
    echo" you are old";
}




?>