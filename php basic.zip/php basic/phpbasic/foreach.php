<?php
$array= array('progaming' ,'deve','de');
foreach($array as $val){
    echo" " .$val;

}









?>