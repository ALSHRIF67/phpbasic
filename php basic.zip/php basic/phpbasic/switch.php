<?php
$test=1;
switch($test){
    case 1:
        echo" caes one here"; 
        break;
        case 2:
            echo" caes  two here"; 
            break;
            case 3:
                echo" caes there here"; 
                break;
                default:
                echo" invaild number";
}






?>