<?php
$a=0;
while($a<10){
    echo"<br/>$a";
    $a++;
}





?>