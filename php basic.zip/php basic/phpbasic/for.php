<?php

for($a=0; $a<10;$a++){
    echo"<br/> hello word $a";
}



?>