<?php
$a=0;
do{

echo"<br/> how ara you$a";
$a++;
}

while($a<10);




?>