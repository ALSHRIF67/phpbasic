<?php

//start session 
session_start();
// storing value insession 
$_SESSION['id'];
// conditional usage of session values that may have been set in a previous session
if(isset($_session['login '])){
    echo"  frist login   ";
    exit;
}
//now login safely
$user =$_SESSION['login']; 
// Getting a value from the session data, or with default value,
// using the Null Coalescing operator in PHP 7
$name= $_session['name']?? 'anymons';
// Note: This will destroy the session, and not just the session data!
if (ini_get("session.use_cookies")) {
   $params = session_get_cookie_params();
 setcookie(session_name(), '', time() - 42000,
  $params["path"], $params["domain"],
   $params["secure"], $params["httponly"]
 );
}
//Finally we can destroy the session:
session_destroy();
