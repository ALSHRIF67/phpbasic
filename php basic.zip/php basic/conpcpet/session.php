<?php

// php<7
//session start
 session_start();
 // write data to session
$_SESSION['id']=123;
// close the session, release lock
 session_write_close();








?>