<?php
//The password_hash method will convert the password 
//entered by the user into a secured hashed password that can then be saved in a database table
$password=password_hash($v1,PASSWORD_DEFAULT,$password);
?>
<?php
/* Determine if an existing password hash can be
upgraded to a stronger algorithm*/
//first determine if a supplied password is valid
if(password_verify($palnitextpassword,$haspassord)){
    //// now determine if the existing hash was created with an algorithm that is
 // no longer the default
 if(password_needs_rehash($haspassord,PASSWORD_DEFAULT)){


    $newhashpassword=password_hash($palnitextpassword,PASSWORD_DEFAULT);
    // create a new hash with the new default
    // and then save it to your data store
 //$db->update(...);

 }

}


?>
<?php
// determines how strong this version of Bcrypt is
if(substr($haspassord,0.4)=='$y2$ '&& strlen($haspassord)==60){
    echo"  done";
    // the "cost" determines how strong this version of Bcrypt is
  preg_match('/\$2y\$(\d+)\$/',$password,$match);
  $cost=$match[1];
  echo"crpit".$cost;

}




?>
<?php
//Verifying a password against a hash password
if (password_verify($palnitextpassword,$password)){
    echo"vaild password";

}else{
    echo" invaild password";
}



?>