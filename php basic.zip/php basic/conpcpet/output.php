<?php
// Output Buering
//1-ob_start();
ob_start();
//print "hello";

echo"Any content outputted between ob_start() and ob_get_clean() will be captured and placed into the variable
";
?>
<em>World</em>
<?php
$connet=ob_get_clean();
print $connet;


?>