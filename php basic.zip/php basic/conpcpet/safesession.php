<?php
// safe session start with on erro
if(version_compare(PHP_VERSION,'7.0.0')>=0){
   if(session_status()== PHP_session_NONE){
    session_start(array(
        'cache_limiter' => 'private',
      'read_and_close' => true,


    ));
   }

} 
elseif(version_compare(php_version,'5.0.0')>=0){
    if(session_status()== PHP_session_NONE){
    session_start();
    }

}else{

if(session_id ()==''){
    session_start();
}
}


//NOTS
//Session name is the name of the cookie used to store sessions.
if(isset($_COOKIE[session_name()])) {
    session_start();
   }



?>